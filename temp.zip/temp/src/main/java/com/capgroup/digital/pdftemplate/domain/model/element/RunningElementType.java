package com.capgroup.digital.pdftemplate.domain.model.element;

public enum RunningElementType {

	NONE("NONE"),
	HEADER("HEADER"),
	FOOTER("FOOTER");
	
	private String code;
	
	RunningElementType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
}
