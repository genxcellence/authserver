package com.capgroup.digital.pdftemplate.interfaces;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgroup.digital.pdftemplate.domain.model.Report;
import com.capgroup.digital.pdftemplate.domain.model.Format;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElementType;
import com.capgroup.digital.pdftemplate.domain.service.ReportService;

@RequestMapping("/v1")
@RestController
public class PdfController {

	@Autowired
	ReportService pdfService;
    
    @GetMapping("/test-pdf")
    public byte[] testPDF() throws IOException {
    	return pdfService.testPDF();
    }
    
    @PostMapping("/pdf")
    public byte[] createPDF(@RequestBody Report data, @RequestParam(required = false, defaultValue = "NONE") Format format, @RequestParam(name = "include", required = false, defaultValue = "NONE") List<RunningElementType> elements) throws IOException {
     	return pdfService.createPDF(data, format, elements);
    }
    
}