package com.capgroup.digital.pdftemplate.domain.model.element;

import com.capgroup.digital.pdftemplate.domain.model.Position;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Element {

	private String text;
	private Position position;
	private int fontSize = 8;
	private boolean includeFirstPage;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Position getPosition() {
		return position;
	}
	public void setPosition(Position position) {
		this.position = position;
	}
	public int getFontSize() {
		return fontSize;
	}
	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}
	@JsonProperty("includeFirstPage")
	public boolean isIncludeFirstPage() {
		return includeFirstPage;
	}
	public void setIncludeFirstPage(boolean includeFirstPage) {
		this.includeFirstPage = includeFirstPage;
	}
	
}
