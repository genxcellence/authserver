package com.capgroup.digital.pdftemplate.infrastructure.itext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import com.capgroup.digital.pdftemplate.ThymeleafConfig;
import com.capgroup.digital.pdftemplate.domain.model.Report;
import com.capgroup.digital.pdftemplate.domain.model.Format;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElement;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElementType;
import com.capgroup.digital.pdftemplate.domain.service.ReportService;
import com.itextpdf.forms.PdfPageFormCopier;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.licensekey.LicenseKey;

@Service
public class ItextPdfService implements ReportService {
	
    @Autowired
    private ThymeleafConfig config;
	
    private static final String PAGENUMBER = "pageNumber";
    
 	private ConverterProperties properties = new ConverterProperties();
 	private Context context = new Context();
 	private PdfPageFormCopier copier = new PdfPageFormCopier();
 	
 	@Override
	public byte[] testPDF() throws IOException {
		
		properties.setBaseUri(getResources());
        String[] samplePages = {"sample"};
        
        ByteArrayOutputStream output = new ByteArrayOutputStream();
    	PdfWriter writer = new PdfWriter(output);
    	PdfDocument pdf = new PdfDocument(writer);
    	
    	combinePages(pdf, samplePages, context, Format.LANDSCAPE);
    	
    	pdf.close();
    	return output.toByteArray();
	}
	
 	@Override
	public byte[] createPDF(Report data, Format format, List<RunningElementType> elements) throws IOException {
		
		loadItext7License();
		
		properties.setBaseUri(getResources());
        context.setVariables(data.getData());
        String[] pages = data.getTemplates();
    	
        ByteArrayOutputStream output = new ByteArrayOutputStream();
    	PdfWriter writer = new PdfWriter(output);
    	PdfDocument pdf = new PdfDocument(writer);
    	
    	combinePages(pdf, pages, context, format);
    	
    	try(Document doc = new Document(pdf)) {
	    	if(elements.contains(RunningElementType.HEADER)) {
	    		addRunningElement(pdf, doc, RunningElementType.HEADER, data.getHeader());
	    	}
	    	if(elements.contains(RunningElementType.FOOTER)) {
	    		addRunningElement(pdf, doc, RunningElementType.FOOTER, data.getFooter());
	    	}
    	}
    	
    	pdf.close();
        return output.toByteArray();
        
    }
    
	private void combinePages(PdfDocument parent, String[] pages, Context variables, Format format) throws IOException {
		int count = 1;
    	for (String html : pages) {
    		
    		variables.setVariable(PAGENUMBER, count);
    		String processedHtml = config.templateEngine().process(html, variables);
    		
    		ByteArrayOutputStream baos = new ByteArrayOutputStream();
    		PdfDocument temp = new PdfDocument(new PdfWriter(baos));
    		
    		count++;
    		
    		if(format != null && format.equals(Format.LANDSCAPE)) {
    			temp.setDefaultPageSize(PageSize.A4.rotate());
    		}
    		
			HtmlConverter.convertToPdf(processedHtml, temp, properties);
            temp = new PdfDocument(new PdfReader(new ByteArrayInputStream(baos.toByteArray())));
            temp.copyPagesTo(1, temp.getNumberOfPages(), parent, copier);
            temp.close();
    	}
	}
	
	private void addRunningElement(PdfDocument pdf, Document doc, RunningElementType runningElementType, RunningElement runningElement) {
        if(runningElementType.equals(RunningElementType.HEADER)) {
        	pdf.addEventHandler(PdfDocumentEvent.END_PAGE, new HeaderEvent(doc, runningElement));
        }
        if(runningElementType.equals(RunningElementType.FOOTER)) {
        	pdf.addEventHandler(PdfDocumentEvent.END_PAGE, new FooterEvent(doc, runningElement));
        }
	}
	
    private String getResources() {
    	URL url = getClass().getResource("/static/");
    	return url.toString();
    }
	
    private void loadItext7License() throws IOException {
    	URL url = getClass().getResource("/itextkeys/");
    	Path path = Paths.get(URI.create(url.toString())); 
    	try (Stream<Path> paths = Files.walk(path)) {
    		List<String> result = paths.filter(Files::isRegularFile)
    				.map(Path::toString).collect(Collectors.toList());
    		String[] keys = new String[result.size()];
    		for(int i = 0; i < result.size(); i++) {
    			keys[i] = result.get(i);
    		}
        	LicenseKey.loadLicenseFile(keys);
    	} 
    }

}
