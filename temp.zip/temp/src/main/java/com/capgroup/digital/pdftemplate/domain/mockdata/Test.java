package com.capgroup.digital.pdftemplate.domain.mockdata;

public class Test {

    String json = "{\"clientName\":\"Test\",\"planType\":\"pptpa\",\"planAssets\":\"20000\",\"estimatedAnnContributions\":\"50000\",\"wilShireService\":\"NA\",\"isEDJ\":false,\"numParticipants\":\"2\",\"shareClassTypesR2\":\"R-2\",\"shareClassTypesR2E\":\"R-2E\",\"shareClassTypesR3\":\"R-3\",\"shareClassTypesR4\":\"R-4\",\"shareClassTypesR5E\":\"R-5E\",\"shareClassTypesR5\":\"R-5\",\"shareClassTypesR6\":\"\",\"tpaFee\":\"12000\",\"adviserFee\":\"\",\"isDollarAdviserFee\":\"\",\"mShareClassType\":\"\",\"mileStone\":\"\",\"mr2\":\"R-2\",\"mr2e\":\"R-2E\",\"mr3\":\"R-3\",\"mr4\":\"R-4\",\"mr5e\":\"R-5E\",\"mr5\":\"R-5\",\"mr6\":\"\",\"includeMileStone\":\"true\",\"includeResult\":\"true\",\"calculateCost\":\"\",\"clientVersion\":\"Create PDF\",\"previous\":\"\",\"fileName\":\"price-it-tool-report.pdf\",\"pdfPluginInstalled\":\"false\",\"priceBand1\":\"\",\"priceBand2\":\"\",\"priceBand3\":\"\",\"priceBand4\":\"\",\"priceBand5\":\"\",\"priceBand6\":\"\",\"priceBand7\":\"\",\"priceBand8\":\"\",\"milestonePriceBand1\":\"\",\"milestonePriceBand2\":\"\",\"milestonePriceBand3\":\"\",\"milestonePriceBand4\":\"\",\"milestonePriceBand5\":\"\",\"milestonePriceBand6\":\"\",\"milestonePriceBand7\":\"\",\"milestonePriceBand8\":\"\",\"adviserFeeGVA\":\"\",\"isDollarAdviserFeeGVA\":\"\",\"isCompanyHeadQuarterInNewYork\":\"\",\"adviserHighLowFee\":\"\",\"creditR2\":\"\",\"creditR2e\":\"\",\"creditR3\":\"\",\"creditR4\":\"\",\"creditR5\":\"0\",\"creditR5e\":\"0\",\"creditR6\":\"0\",\"r2Fpo\":\"0.65\",\"r2eFpo\":\"0.5\",\"r3Fpo\":\"0.35\",\"r4Fpo\":\"0.25\",\"r5eFpo\":\"0\",\"r5po\":\"0\",\"r6po\":\"\",\"page\":0}";

   // Gson gson = new Gson();

}
