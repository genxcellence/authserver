package com.capgroup.digital.pdftemplate.domain.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capgroup.digital.pdftemplate.domain.model.Report;
import com.capgroup.digital.pdftemplate.domain.model.Format;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElementType;

@Service
public interface ReportService {

	public byte[] testPDF() throws IOException;
	
	public byte[] createPDF(Report data, Format format, List<RunningElementType> elements) throws IOException;
	
}
