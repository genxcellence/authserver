import React from "react";
import "./Footer.scss";

const Footer = () => (
  <div className="footer-component">
    <div className="footer">
      <div className="footer-container">
        <div className="copyright">
          © 2020 Capital Group. All rights reserved.
          </div>
      </div> </div>
  </div>
);

export default Footer;

