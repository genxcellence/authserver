import React from 'react';
import MainComponent from "./mainComponent";
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
import configureStore from 'redux-mock-store';

configure({ adapter: new Adapter() });

describe('New event container', () => {
  it('Should have at least one div', () => {
    const _wrapper1 = shallow(<MainComponent />)
    expect(_wrapper1.find('div').length > 0)
  })

});

