import React from 'react';
import { connect } from 'react-redux';
import './mainComponent.scss';

class MainComponent extends React.Component {
    render() {
        return (
            <div >
                <div className="container">
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
    };
};
const mapDispatchToProps = (state) => {
    return {
    };
};
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(MainComponent);