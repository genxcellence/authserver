const initalState = {
    list: []
};

export function handleEventReducer(state = initalState, actions) {
    switch (actions.type) {
        case "LOAD_LIST": {
            const stateObj = {
                list: actions.data
            }
            return Object.assign({}, state, stateObj);
        }
        default:
            return state
    }

}