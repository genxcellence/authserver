export const receivedList = (data) => {
    return {
        type: 'LOAD_LIST',
        data
    }
}

export const getList = () => {
    return (dispatch) => {
        return fetch('url')
            .then(response => response.json())
            .then(data => dispatch(receivedList(data)));
    }
}
