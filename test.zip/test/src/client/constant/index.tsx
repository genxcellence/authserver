// routes
export const HOME_PAGE_URI = "/";
export const LOGOUT_PAGE_URI = "/logout";

// entitlements
export const READ_ACCESS = "read";
export const WRITE_ACCESS = "write";


